# hm.tarot ✦ — Android-проект

Этот проект упаковывает последнюю сохранённую HTML-версию `hm_tarot_updated_v2.html` в Android-приложение. HTML/CSS/JavaScript и встроенные изображения лежат внутри приложения в `app/src/main/assets/index.html`, поэтому сайт открывается локально и не зависит от Netlify или подключения к интернету для работы раскладов.

## Получить APK через Android Studio

1. Установить Android Studio на компьютер.
2. Открыть в Android Studio папку `hm_tarot_android_project`.
3. Дождаться синхронизации Gradle и установки Android SDK 35, если программа попросит.
4. Выбрать **Build → Build APK(s)**.
5. APK для установки на телефон появится в `app/build/outputs/apk/debug/app-debug.apk`.

## Автоматически собрать APK через GitHub Actions

В проект включён workflow `.github/workflows/build-apk.yml`. После загрузки файлов в GitHub-репозиторий откройте вкладку **Actions**, выберите **Build hm.tarot APK** и нажмите **Run workflow** (или дождитесь сборки после push). В завершённом запуске скачайте артефакт `hm-tarot-android-apk` — внутри будет `app-debug.apk`.

## Технические параметры

- Имя: `hm.tarot ✦`
- Android package: `com.hmtarot.app`
- Минимальная версия Android: Android 7.0 (API 24)
- Версия приложения: `1.0.0`
- Не запрашивает разрешения на интернет или контакты.
- Внешние HTTPS-ссылки открываются в браузере устройства.

## Важно

Это исходный проект, а не готовый APK: в рабочей среде, где он был подготовлен, не установлен Android SDK/Gradle и нет сетевого доступа для загрузки инструментов сборки. Файл APK поэтому здесь не был скомпилирован или проверен на Android-устройстве.
